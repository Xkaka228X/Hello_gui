package com.hidenseek.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;

/**
 * Меню выбора категорий ESP.
 * Открывается клавишей Right Shift.
 */
public class ESPMenuScreen extends Screen {

    private static final int W = 240;
    private static final int H = 230;

    // Цвета категорий (ARGB для drawString)
    private static final int COL_PLAYER  = 0xFFFFFFFF; // белый
    private static final int COL_PASSIVE = 0xFF22FF22; // зелёный
    private static final int COL_HOSTILE = 0xFFFF3333; // красный
    private static final int COL_VEHICLE = 0xFFCC44FF; // фиолетовый

    public ESPMenuScreen() {
        super(new StringTextComponent("ESP Меню"));
    }

    @Override
    protected void init() {
        int left = (this.width  - W) / 2;
        int top  = (this.height - H) / 2;

        // ── Кнопка "Режим искателя" ──────────────────────────────────────────
        this.addButton(new Button(left + 10, top + 34, W - 20, 20,
                new StringTextComponent(seekerLabel()),
                btn -> {
                    ESPConfig.seekerModeEnabled = !ESPConfig.seekerModeEnabled;
                    btn.setMessage(new StringTextComponent(seekerLabel()));
                }));

        // ── Кнопки категорий ─────────────────────────────────────────────────
        int by = top + 70;
        int bw = (W - 30) / 2;

        addToggleButton(left + 10,        by,      bw, "⬜ Игроки",     COL_PLAYER,
                () -> ESPConfig.showPlayers,
                v  -> ESPConfig.showPlayers = v);

        addToggleButton(left + 20 + bw,   by,      bw, "✦ Мирные",     COL_PASSIVE,
                () -> ESPConfig.showPassive,
                v  -> ESPConfig.showPassive = v);

        addToggleButton(left + 10,        by + 30, bw, "☠ Враждебные", COL_HOSTILE,
                () -> ESPConfig.showHostile,
                v  -> ESPConfig.showHostile = v);

        addToggleButton(left + 20 + bw,   by + 30, bw, "◈ Объекты",    COL_VEHICLE,
                () -> ESPConfig.showVehicles,
                v  -> ESPConfig.showVehicles = v);

        // ── Кнопки "Все" / "Ничего" ──────────────────────────────────────────
        this.addButton(new Button(left + 10, by + 70, bw, 20,
                new StringTextComponent("§aВключить все"),
                btn -> {
                    ESPConfig.showPlayers = ESPConfig.showPassive =
                    ESPConfig.showHostile = ESPConfig.showVehicles = true;
                    rebuildButtons();
                }));

        this.addButton(new Button(left + 20 + bw, by + 70, bw, 20,
                new StringTextComponent("§cВыключить все"),
                btn -> {
                    ESPConfig.showPlayers = ESPConfig.showPassive =
                    ESPConfig.showHostile = ESPConfig.showVehicles = false;
                    rebuildButtons();
                }));

        // ── Закрыть ──────────────────────────────────────────────────────────
        this.addButton(new Button(left + 10, top + H - 34, W - 20, 24,
                new StringTextComponent("§7Закрыть [RShift / Esc]"),
                btn -> this.onClose()));
    }

    /** Хелпер — кнопка-переключатель с цветовой меткой */
    private void addToggleButton(int x, int y, int w, String label, int labelColor,
                                  java.util.function.BooleanSupplier getter,
                                  java.util.function.Consumer<Boolean> setter) {
        this.addButton(new Button(x, y, w, 20,
                new StringTextComponent(toggleLabel(label, getter.getAsBoolean())),
                btn -> {
                    boolean nv = !getter.getAsBoolean();
                    setter.accept(nv);
                    btn.setMessage(new StringTextComponent(toggleLabel(label, nv)));
                }
        ));
    }

    private static String toggleLabel(String name, boolean on) {
        return on ? ("§a[ВКЛ] §r" + name) : ("§c[ВЫКЛ] §8" + name);
    }

    private static String seekerLabel() {
        return ESPConfig.seekerModeEnabled
                ? "§a● Режим искателя: ВКЛЮЧЁН"
                : "§c● Режим искателя: ВЫКЛЮЧЕН";
    }

    private void rebuildButtons() {
        this.buttons.clear();
        this.children.clear();
        this.init();
    }

    // ── Рисуем фон и заголовок ────────────────────────────────────────────────
    @Override
    public void render(MatrixStack ms, int mx, int my, float tick) {
        this.renderBackground(ms);

        int left = (this.width  - W) / 2;
        int top  = (this.height - H) / 2;

        // Тёмная панель
        fill(ms, left, top, left + W, top + H, 0xDD101018);
        // Рамка
        hLine(ms, left,      left + W - 1, top,      0xFFAA44FF);
        hLine(ms, left,      left + W - 1, top + H - 1, 0xFFAA44FF);
        vLine(ms, left,      top, top + H, 0xFFAA44FF);
        vLine(ms, left + W - 1, top, top + H, 0xFFAA44FF);

        // Заголовок
        String title = "§d§l⚡ ESP — Настройки";
        this.font.drawShadow(ms, title,
                left + (W - this.font.width(title)) / 2f, top + 10, 0xFFFFFF);

        // Разделитель под заголовком
        hLine(ms, left + 4, left + W - 5, top + 28, 0x88AA44FF);

        // Легенда цветов
        int ly = top + H - 60;
        this.font.drawShadow(ms, "§7Цвета ESP:", left + 10, ly, 0xFFFFFF);
        this.font.drawShadow(ms, "§fИгроки  §aМирные  §cВрагов  §dОбъекты",
                left + 10, ly + 11, 0xFFFFFF);

        super.render(ms, mx, my, tick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
