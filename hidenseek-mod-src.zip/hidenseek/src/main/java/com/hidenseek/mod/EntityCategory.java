package com.hidenseek.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.passive.horse.*;

public enum EntityCategory {

    PLAYER  ("Игроки",    new float[]{1.0f, 1.0f, 1.0f, 1.0f}),   // белый
    PASSIVE ("Мирные",    new float[]{0.2f, 1.0f, 0.2f, 1.0f}),   // зелёный
    HOSTILE ("Враждебные",new float[]{1.0f, 0.15f, 0.15f, 1.0f}), // красный
    VEHICLE ("Объекты",   new float[]{0.75f, 0.2f, 1.0f, 1.0f}),  // фиолетовый
    IGNORE  ("",          new float[]{0,0,0,0});

    public final String displayName;
    private final float[] color;

    EntityCategory(String name, float[] color) {
        this.displayName = name;
        this.color = color;
    }

    public float[] getColor() { return color; }

    public boolean isEnabled() {
        switch (this) {
            case PLAYER:  return ESPConfig.showPlayers;
            case PASSIVE: return ESPConfig.showPassive;
            case HOSTILE: return ESPConfig.showHostile;
            case VEHICLE: return ESPConfig.showVehicles;
            default:      return false;
        }
    }

    /** Классифицирует сущность */
    public static EntityCategory classify(Entity e) {
        if (e instanceof PlayerEntity)      return PLAYER;

        // Враждебные — проверяем сначала, т.к. некоторые наследуются от MobEntity
        if (e instanceof MonsterEntity)     return HOSTILE;
        if (e instanceof SlimeEntity)       return HOSTILE;
        if (e instanceof GhastEntity)       return HOSTILE;
        if (e instanceof PhantomEntity)     return HOSTILE;
        if (e instanceof ElderGuardianEntity) return HOSTILE;
        if (e instanceof GuardianEntity)    return HOSTILE;
        if (e instanceof ShulkerEntity)     return HOSTILE;
        if (e instanceof BlazeEntity)       return HOSTILE;

        // Мирные живые мобы
        if (e instanceof AnimalEntity)      return PASSIVE;
        if (e instanceof AmbientEntity)     return PASSIVE;
        if (e instanceof WaterMobEntity)    return PASSIVE;
        if (e instanceof AbstractHorseEntity) return PASSIVE;
        if (e instanceof TameableEntity)    return PASSIVE;
        if (e instanceof VillagerEntity)    return PASSIVE;
        if (e instanceof IronGolemEntity)   return PASSIVE;
        if (e instanceof SnowGolemEntity)   return PASSIVE;

        // Объекты/транспорт
        if (e instanceof BoatEntity)        return VEHICLE;
        if (e instanceof MinecartEntity)    return VEHICLE;
        if (e instanceof ArmorStandEntity)  return VEHICLE;
        if (e instanceof ItemEntity)        return VEHICLE;
        if (e instanceof ItemFrameEntity)   return VEHICLE;
        if (e instanceof FallingBlockEntity) return VEHICLE;
        if (e instanceof TNTEntity)         return VEHICLE;

        return IGNORE;
    }
}
