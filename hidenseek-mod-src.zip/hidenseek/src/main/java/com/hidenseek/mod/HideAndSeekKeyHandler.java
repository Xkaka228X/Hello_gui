package com.hidenseek.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.util.InputMappings;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = HideAndSeekMod.MOD_ID)
public class HideAndSeekKeyHandler {

    /** O — вкл/выкл режим искателя */
    public static final KeyBinding TOGGLE_KEY = new KeyBinding(
            "key.hidenseek.toggle",
            InputMappings.Type.KEYSYM,
            GLFW.GLFW_KEY_O,
            "key.categories.hidenseek"
    );

    /** Right Shift — открыть меню категорий */
    public static final KeyBinding MENU_KEY = new KeyBinding(
            "key.hidenseek.menu",
            InputMappings.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "key.categories.hidenseek"
    );

    static {
        ClientRegistry.registerKeyBinding(TOGGLE_KEY);
        ClientRegistry.registerKeyBinding(MENU_KEY);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        Minecraft mc = Minecraft.getInstance();

        // O — переключить ESP
        if (TOGGLE_KEY.consumeClick()) {
            ESPConfig.seekerModeEnabled = !ESPConfig.seekerModeEnabled;
            if (mc.player != null) {
                mc.player.sendMessage(
                        new StringTextComponent(
                                ESPConfig.seekerModeEnabled
                                        ? "§d[ESP] §fРежим искателя §aВКЛЮЧЁН"
                                        : "§d[ESP] §fРежим искателя §cВЫКЛЮЧЕН"
                        ),
                        mc.player.getUUID()
                );
            }
        }

        // Right Shift — открыть меню (только если не открыт другой экран)
        if (MENU_KEY.consumeClick()) {
            if (mc.screen == null) {
                mc.setScreen(new ESPMenuScreen());
            }
        }
    }
}
