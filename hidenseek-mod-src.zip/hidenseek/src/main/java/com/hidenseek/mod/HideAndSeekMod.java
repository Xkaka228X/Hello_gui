package com.hidenseek.mod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(HideAndSeekMod.MOD_ID)
public class HideAndSeekMod {
    public static final String MOD_ID = "hidenseek";
    public static final Logger LOGGER = LogManager.getLogger();

    public HideAndSeekMod() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::clientSetup);
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        MinecraftForge.EVENT_BUS.register(new HideAndSeekOverlay());
        MinecraftForge.EVENT_BUS.register(new HideAndSeekKeyHandler());
        LOGGER.info("HideAndSeek ESP mod loaded! O = toggle, RShift = menu");
    }
}
