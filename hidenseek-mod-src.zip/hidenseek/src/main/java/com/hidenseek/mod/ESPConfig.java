package com.hidenseek.mod;

/** Глобальное состояние — что включено в ESP */
public class ESPConfig {
    public static boolean seekerModeEnabled = false;

    public static boolean showPlayers  = true;
    public static boolean showPassive  = true;
    public static boolean showHostile  = true;
    public static boolean showVehicles = true;
}
