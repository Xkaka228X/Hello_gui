package com.hidenseek.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector4f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = HideAndSeekMod.MOD_ID)
public class HideAndSeekOverlay extends AbstractGui {

    // ─── 3D ESP: боксы сквозь стены ──────────────────────────────────────────
    @SubscribeEvent
    public static void onRenderWorld(RenderWorldLastEvent event) {
        if (!ESPConfig.seekerModeEnabled) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        MatrixStack ms = event.getMatrixStack();
        ActiveRenderInfo camera = mc.gameRenderer.getMainCamera();
        Vector3d camPos = camera.getPosition();

        List<EntityEntry> entries = collectEntities(mc);

        // 3D боксы
        for (EntityEntry e : entries) {
            Entity ent = e.entity;
            float[] c = e.category.getColor();

            ms.pushPose();
            ms.translate(
                    ent.getX() - camPos.x,
                    ent.getY() - camPos.y,
                    ent.getZ() - camPos.z
            );

            AxisAlignedBB box = new AxisAlignedBB(
                    -ent.getBbWidth() / 2f, 0, -ent.getBbWidth() / 2f,
                    ent.getBbWidth() / 2f, ent.getBbHeight(), ent.getBbWidth() / 2f
            );

            RenderSystem.enableDepthTest();
            RenderSystem.depthFunc(GL11.GL_ALWAYS); // рисуем СКВОЗЬ стены
            RenderSystem.disableTexture();
            RenderSystem.lineWidth(1.6f);

            WorldRenderer.renderLineBox(ms,
                    mc.renderBuffers().bufferSource().getBuffer(
                            net.minecraft.client.renderer.RenderType.lines()),
                    box, c[0], c[1], c[2], c[3]);

            RenderSystem.depthFunc(GL11.GL_LEQUAL);
            RenderSystem.enableTexture();
            ms.popPose();
        }

        // 2D линии от центра
        draw2DLines(mc, event.getMatrixStack(), event.getProjectionMatrix(), camPos, entries);
    }

    // ─── Линии от центра экрана до энтити ────────────────────────────────────
    private static void draw2DLines(Minecraft mc, MatrixStack ms, Matrix4f proj,
                                     Vector3d camPos, List<EntityEntry> entries) {
        if (mc.player == null) return;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        float cx = sw / 2f, cy = sh / 2f;

        for (EntityEntry e : entries) {
            Entity ent = e.entity;
            Vector3d rel = ent.position().add(0, ent.getBbHeight() / 2.0, 0).subtract(camPos);

            Matrix4f vp = ms.last().pose().copy();
            vp.multiply(proj);

            Vector4f p = new Vector4f((float)rel.x, (float)rel.y, (float)rel.z, 1f);
            p.transform(vp);
            if (p.w <= 0) continue;

            float sx = (p.x / p.w * 0.5f + 0.5f) * sw;
            float sy = (1f - (p.y / p.w * 0.5f + 0.5f)) * sh;

            float[] c = e.category.getColor();
            drawLine2D(cx, cy, sx, sy,
                    (int)(c[0]*255), (int)(c[1]*255), (int)(c[2]*255), 170);
        }
    }

    // ─── 2D HUD overlay ───────────────────────────────────────────────────────
    @SubscribeEvent
    public static void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (!ESPConfig.seekerModeEnabled) return;
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        MatrixStack ms = new MatrixStack();
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        List<EntityEntry> entries = collectEntities(mc);

        // ── Левая панель: игроки с подробной инфой ───────────────────────────
        mc.font.drawShadow(ms, "§d§l⚡ ESP §7Режим искателя", 4, 4, 0xFFFFFF);

        int yOff = 18, pi = 0;
        for (EntityEntry e : entries) {
            if (e.category != EntityCategory.PLAYER) continue;
            PlayerEntity target = (PlayerEntity) e.entity;

            String name  = target.getName().getString();
            int hp       = (int) Math.ceil(target.getHealth());
            int maxHp    = (int) Math.ceil(target.getMaxHealth());
            int armor    = target.getArmorValue();
            int dist     = (int) mc.player.distanceTo(target);
            ItemStack held = target.getMainHandItem();
            String item  = held.isEmpty() ? "§8пусто" : "§f" + held.getHoverName().getString();
            String hpCol = hp > maxHp * 0.6 ? "§a" : hp > maxHp * 0.3 ? "§e" : "§c";

            int py = yOff + pi * 50;
            // Фон строки
            fill(ms, 2, py - 1, 226, py + 46, 0x99000000);
            // Белая полоска слева — цвет категории
            fill(ms, 2, py - 1, 4, py + 46, 0xFFFFFFFF);

            mc.font.drawShadow(ms, "§f" + name + " §7(" + dist + "м)", 7, py + 1,  0xFFFFFF);
            mc.font.drawShadow(ms, "❤ " + hpCol + hp + "§7/" + maxHp + "  §6⛨ §f" + armor, 7, py + 13, 0xFFFFFF);
            mc.font.drawShadow(ms, "§7Рука: " + item, 7, py + 25, 0xFFFFFF);

            // HP-бар
            int bw = 120, bf = (int)((float) hp / maxHp * bw);
            int by2 = py + 37;
            fill(ms, 7, by2, 7 + bw, by2 + 4, 0xFF333333);
            int bc = hp > maxHp*0.6 ? 0xFF22CC22 : hp > maxHp*0.3 ? 0xFFCCAA00 : 0xFFCC2222;
            fill(ms, 7, by2, 7 + bf, by2 + 4, bc);
            pi++;
        }

        // ── Правая панель: счётчики других категорий ─────────────────────────
        int[] counts = new int[4]; // [player, passive, hostile, vehicle]
        for (EntityEntry e : entries) {
            switch (e.category) {
                case PLAYER:  counts[0]++; break;
                case PASSIVE: counts[1]++; break;
                case HOSTILE: counts[2]++; break;
                case VEHICLE: counts[3]++; break;
            }
        }

        int rx = sw - 130, ry = 4;
        fill(ms, rx - 4, ry - 2, sw - 2, ry + 58, 0x99000000);
        fill(ms, rx - 4, ry - 2, rx - 2, ry + 58, 0xFFDD44FF); // фиолетовая полоска

        if (ESPConfig.showPlayers)
            mc.font.drawShadow(ms, "§f⬜ Игроки: §7"   + counts[0], rx, ry,      0xFFFFFF);
        if (ESPConfig.showPassive)
            mc.font.drawShadow(ms, "§a✦ Мирные: §7"   + counts[1], rx, ry + 14, 0xFFFFFF);
        if (ESPConfig.showHostile)
            mc.font.drawShadow(ms, "§c☠ Враги: §7"    + counts[2], rx, ry + 28, 0xFFFFFF);
        if (ESPConfig.showVehicles)
            mc.font.drawShadow(ms, "§d◈ Объекты: §7"  + counts[3], rx, ry + 42, 0xFFFFFF);

        // ── Подсказки снизу ──────────────────────────────────────────────────
        String hint = "§7[O] вкл/выкл ESP   [RShift] настройки";
        mc.font.draw(ms, hint, sw / 2f - mc.font.width(hint) / 2f, sh - 18, 0x888888);
    }

    // ─── Сбор сущностей ───────────────────────────────────────────────────────
    private static List<EntityEntry> collectEntities(Minecraft mc) {
        List<EntityEntry> result = new ArrayList<>();
        if (mc.level == null || mc.player == null) return result;
        for (Entity ent : mc.level.entitiesForRendering()) {
            if (ent == mc.player) continue;
            EntityCategory cat = EntityCategory.classify(ent);
            if (cat == EntityCategory.IGNORE || !cat.isEnabled()) continue;
            result.add(new EntityEntry(ent, cat));
        }
        return result;
    }

    // ─── Вспомогательные классы и методы ─────────────────────────────────────
    static class EntityEntry {
        final Entity entity;
        final EntityCategory category;
        EntityEntry(Entity e, EntityCategory c) { entity = e; category = c; }
    }

    private static void drawLine2D(float x1, float y1, float x2, float y2,
                                    int r, int g, int b, int alpha) {
        RenderSystem.enableBlend();
        RenderSystem.disableTexture();
        RenderSystem.lineWidth(1.3f);
        RenderSystem.defaultBlendFunc();

        com.mojang.blaze3d.vertex.BufferBuilder bb =
                net.minecraft.client.renderer.Tessellator.getInstance().getBuilder();
        bb.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        bb.vertex(x1, y1, 0).color(r, g, b, alpha).endVertex();
        bb.vertex(x2, y2, 0).color(r, g, b, alpha).endVertex();
        net.minecraft.client.renderer.Tessellator.getInstance().end();

        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
    }
}
